import React from "react";

const GopaynetQrCode = () => {
  return <div>GopaynetQrCode</div>;
};

export default GopaynetQrCode;
