import React from "react";

const Dashboard = () => {
  return (
    <div>
      <h1 className="text-center font-bold text-[50px] h-screen text-green-500 my-auto mt-10 uppercase">
        successfully authenticated
      </h1>
    </div>
  );
};

export default Dashboard;
